import { sql } from 'drizzle-orm';
import type { FastifyPluginAsync } from 'fastify';
import {
  checkDuplicateQuery,
  createPlaceInput,
  DUPLICATE_RADIUS_M,
  searchPlacesQuery,
  updatePlaceInput,
} from '@win/shared';
import { db } from '../db/client.js';
import { conflict, notFound, parse } from '../lib/http.js';

/** Colonnes renvoyees a l'application, photos comprises. */
const placeColumns = sql`
  p.id,
  p.name,
  p.category,
  ST_Y(p.geom::geometry)          AS lat,
  ST_X(p.geom::geometry)          AS lon,
  p.house_number                  AS "houseNumber",
  p.street,
  p.city,
  p.postal_code                   AS "postalCode",
  p.wilaya,
  p.country,
  p.phone_fixe                    AS "phoneFixe",
  p.phone_mobile                  AS "phoneMobile",
  p.whatsapp,
  p.email,
  p.enseigne,
  p.promo,
  p.is_partner                    AS "isPartner",
  p.created_at                    AS "createdAt",
  p.updated_at                    AS "updatedAt",
  COALESCE(ph.photos, '[]'::json) AS photos
`;

const photosJoin = sql`
  LEFT JOIN LATERAL (
    SELECT json_agg(
             json_build_object(
               'id', f.id,
               'storageKey', f.storage_key,
               'thumbKey', f.thumb_key,
               'credit', f.credit,
               'position', f.position
             ) ORDER BY f.position
           ) AS photos
    FROM place_photos f
    WHERE f.place_id = p.id
  ) ph ON true
`;

const routes: FastifyPluginAsync = async (app) => {
  /**
   * Recherche d'adresses.
   *
   * L'ancien backend relisait addresses.json en entier a chaque appel et
   * filtrait en memoire. Ici, deux index font le travail : trigrammes sur le
   * nom pour la tolerance aux fautes de frappe, GiST sur la position pour
   * remonter d'abord ce qui est proche de l'utilisateur.
   */
  app.get('/places/search', async (req) => {
    const { q, lat, lon, category, limit } = parse(searchPlacesQuery, req.query);
    const hasPosition = lat !== undefined && lon !== undefined;
    const reference = hasPosition
      ? sql`ST_SetSRID(ST_MakePoint(${lon}, ${lat}), 4326)::geography`
      : sql`NULL::geography`;

    const rows = await db.execute(sql`
      SELECT ${placeColumns},
             similarity(win_normalize(p.name), win_normalize(${q}))       AS score,
             CASE WHEN ${hasPosition}
                  THEN ST_Distance(p.geom, ${reference})
             END                                                          AS "distanceM"
      FROM places p
      ${photosJoin}
      WHERE p.deleted_at IS NULL
        AND p.status = 'published'
        AND (${category ?? null}::text IS NULL OR p.category = ${category ?? null})
        AND (
              win_normalize(p.name)  % win_normalize(${q})
           OR win_normalize(p.name)  LIKE win_normalize(${q}) || '%'
           OR win_normalize(COALESCE(p.street, '')) LIKE win_normalize(${q}) || '%'
           OR win_normalize(COALESCE(p.city, ''))   LIKE win_normalize(${q}) || '%'
           OR win_normalize(COALESCE(p.enseigne, '')) % win_normalize(${q})
        )
      ORDER BY p.is_partner DESC,
               score DESC,
               "distanceM" ASC NULLS LAST
      LIMIT ${limit}
    `);

    return { items: rows };
  });

  /**
   * Pre-verification anti-doublon, appelee avant l'enregistrement d'une
   * nouvelle adresse. Meme role que GET /addresses/check en v83, mais la
   * comparaison de proximite se fait en base.
   */
  app.get('/places/check-duplicate', async (req) => {
    const { name, lat, lon } = parse(checkDuplicateQuery, req.query);
    const rows = await db.execute(sql`
      SELECT p.id,
             p.name,
             ST_Distance(p.geom, ST_SetSRID(ST_MakePoint(${lon}, ${lat}), 4326)::geography) AS "distanceM",
             similarity(win_normalize(p.name), win_normalize(${name})) AS score
      FROM places p
      WHERE p.deleted_at IS NULL
        AND ST_DWithin(p.geom, ST_SetSRID(ST_MakePoint(${lon}, ${lat}), 4326)::geography, ${DUPLICATE_RADIUS_M})
      ORDER BY score DESC
      LIMIT 5
    `);

    const candidates = rows as unknown as { score: number; distanceM: number }[];
    const duplicate = candidates.some((c) => Number(c.score) >= 0.45);
    return { duplicate, candidates: rows };
  });

  /** Fiche complete d'un lieu. */
  app.get<{ Params: { id: string } }>('/places/:id', async (req) => {
    const rows = (await db.execute(sql`
      SELECT ${placeColumns}
      FROM places p
      ${photosJoin}
      WHERE p.id = ${req.params.id} AND p.deleted_at IS NULL
      LIMIT 1
    `)) as unknown as unknown[];

    if (rows.length === 0) throw notFound("Ce lieu n'existe pas ou a ete supprime.");
    return rows[0];
  });

  /** Lieux dans la zone visible de la carte. */
  app.get('/places/in-bounds', async (req) => {
    const q = req.query as Record<string, string>;
    const [west, south, east, north] = (q.bbox ?? '').split(',').map(Number);
    if ([west, south, east, north].some((n) => !Number.isFinite(n))) {
      return { items: [] };
    }
    const rows = await db.execute(sql`
      SELECT ${placeColumns}
      FROM places p
      ${photosJoin}
      WHERE p.deleted_at IS NULL
        AND p.status = 'published'
        AND ST_Intersects(
              p.geom,
              ST_MakeEnvelope(${west}, ${south}, ${east}, ${north}, 4326)::geography
            )
      ORDER BY p.is_partner DESC
      LIMIT 300
    `);
    return { items: rows };
  });

  /** Ajout d'un lieu par un contributeur. */
  app.post('/places', { preHandler: [app.requireDevice] }, async (req, reply) => {
    const input = parse(createPlaceInput, req.body);
    const deviceId = req.deviceId!;

    const near = (await db.execute(sql`
      SELECT id FROM places
      WHERE deleted_at IS NULL
        AND similarity(win_normalize(name), win_normalize(${input.name})) >= 0.6
        AND ST_DWithin(geom, ST_SetSRID(ST_MakePoint(${input.lon}, ${input.lat}), 4326)::geography, ${DUPLICATE_RADIUS_M})
      LIMIT 1
    `)) as unknown as { id: string }[];

    if (near.length > 0) {
      throw conflict(
        'lieu_existant',
        'Un lieu portant ce nom existe deja a moins de 60 metres.',
        { placeId: near[0]!.id },
      );
    }

    const rows = (await db.execute(sql`
      INSERT INTO places (name, category, geom, house_number, street, city, postal_code,
                          wilaya, country, phone_fixe, phone_mobile, whatsapp, email,
                          enseigne, promo, created_by)
      VALUES (${input.name}, ${input.category},
              ST_SetSRID(ST_MakePoint(${input.lon}, ${input.lat}), 4326)::geography,
              ${input.houseNumber ?? null}, ${input.street ?? null}, ${input.city ?? null},
              ${input.postalCode ?? null}, ${input.wilaya ?? null}, ${input.country},
              ${input.phoneFixe ?? null}, ${input.phoneMobile ?? null},
              ${input.whatsapp ?? null}, ${input.email ?? null},
              ${input.enseigne ?? null}, ${input.promo ?? null}, ${deviceId})
      RETURNING id
    `)) as unknown as { id: string }[];

    const placeId = rows[0]!.id;

    if (input.photoIds?.length) {
      await db.execute(sql`
        UPDATE place_photos SET place_id = ${placeId}
        WHERE id = ANY(${input.photoIds}::uuid[]) AND place_id IS NULL
      `);
    }

    await db.execute(sql`
      INSERT INTO contributors (device_id, places_count, score)
      VALUES (${deviceId}, 1, 10)
      ON CONFLICT (device_id) DO UPDATE
        SET places_count = contributors.places_count + 1,
            score        = contributors.score + 10,
            updated_at   = now()
    `);

    await db.execute(sql`
      INSERT INTO moderation_log (entity_type, entity_id, action, after, device_id)
      VALUES ('place', ${placeId}, 'create', ${JSON.stringify(input)}::jsonb, ${deviceId})
    `);

    return reply.code(201).send({ id: placeId });
  });

  /** Modification, reservee aux moderateurs. */
  app.patch<{ Params: { id: string } }>(
    '/places/:id',
    { preHandler: [app.requireAdmin] },
    async (req) => {
      const input = parse(updatePlaceInput, req.body);
      const id = req.params.id;

      const before = (await db.execute(
        sql`SELECT * FROM places WHERE id = ${id} AND deleted_at IS NULL`,
      )) as unknown as unknown[];
      if (before.length === 0) throw notFound();

      await db.execute(sql`
        UPDATE places SET
          name         = COALESCE(${input.name ?? null}, name),
          category     = COALESCE(${input.category ?? null}, category),
          house_number = COALESCE(${input.houseNumber ?? null}, house_number),
          street       = COALESCE(${input.street ?? null}, street),
          city         = COALESCE(${input.city ?? null}, city),
          postal_code  = COALESCE(${input.postalCode ?? null}, postal_code),
          wilaya       = COALESCE(${input.wilaya ?? null}, wilaya),
          phone_fixe   = COALESCE(${input.phoneFixe ?? null}, phone_fixe),
          phone_mobile = COALESCE(${input.phoneMobile ?? null}, phone_mobile),
          whatsapp     = COALESCE(${input.whatsapp ?? null}, whatsapp),
          email        = COALESCE(${input.email ?? null}, email),
          enseigne     = COALESCE(${input.enseigne ?? null}, enseigne),
          promo        = COALESCE(${input.promo ?? null}, promo),
          geom         = CASE WHEN ${input.lat ?? null}::double precision IS NOT NULL
                              THEN ST_SetSRID(ST_MakePoint(${input.lon ?? null}, ${input.lat ?? null}), 4326)::geography
                              ELSE geom END
        WHERE id = ${id}
      `);

      await db.execute(sql`
        INSERT INTO moderation_log (entity_type, entity_id, action, before, after, admin_id)
        VALUES ('place', ${id}, 'update',
                ${JSON.stringify(before[0])}::jsonb,
                ${JSON.stringify(input)}::jsonb,
                ${req.admin!.id})
      `);

      return { ok: true };
    },
  );

  /**
   * Suppression. Volontairement logique : la v78 a montre qu'une suppression
   * definitive rend toute restauration impossible, et le journal de moderation
   * existe justement pour pouvoir revenir en arriere.
   */
  app.delete<{ Params: { id: string } }>(
    '/places/:id',
    { preHandler: [app.requireAdmin] },
    async (req) => {
      const id = req.params.id;
      const before = (await db.execute(
        sql`SELECT * FROM places WHERE id = ${id} AND deleted_at IS NULL`,
      )) as unknown as unknown[];
      if (before.length === 0) throw notFound();

      await db.execute(sql`UPDATE places SET deleted_at = now() WHERE id = ${id}`);
      await db.execute(sql`
        INSERT INTO moderation_log (entity_type, entity_id, action, before, admin_id)
        VALUES ('place', ${id}, 'delete', ${JSON.stringify(before[0])}::jsonb, ${req.admin!.id})
      `);

      return { ok: true, restorable: true };
    },
  );
};

export default routes;
