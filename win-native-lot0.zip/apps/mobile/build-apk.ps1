# =============================================================================
# WIN — produit l'APK Android et affiche le lien de telechargement.
#
# A lancer depuis PowerShell, dans le dossier apps\mobile :
#     .\build-apk.ps1
#
# La compilation ne se fait PAS sur votre PC : le code est envoye chez Expo,
# qui compile sur ses machines et renvoie un lien. Vous n'avez besoin ni
# d'Android Studio, ni du SDK Android, ni de 10 Go de telechargement.
# =============================================================================

$ErrorActionPreference = 'Stop'

function Etape($n, $texte) {
    Write-Host ""
    Write-Host "  [$n] $texte" -ForegroundColor Cyan
    Write-Host ""
}
function Bien($texte) { Write-Host "      $texte" -ForegroundColor Green }
function Souci($texte) { Write-Host "      $texte" -ForegroundColor Yellow }

Write-Host ""
Write-Host "  WIN - construction de l'APK Android" -ForegroundColor White
Write-Host "  ===================================" -ForegroundColor DarkGray

# --- 1. Node --------------------------------------------------------------
Etape 1 "Verification de Node"

try {
    $versionNode = (node -v).TrimStart('v')
} catch {
    throw "Node n'est pas installe. Telechargez la version LTS sur https://nodejs.org puis relancez ce script."
}

$majeure = [int]($versionNode -split '\.')[0]
if ($majeure -lt 22) {
    throw "Node $versionNode est trop ancien. Il faut la version 22 ou plus : https://nodejs.org"
}
Bien "Node $versionNode"

# --- 2. Dependances -------------------------------------------------------
Etape 2 "Installation des dependances (quelques minutes la premiere fois)"

$racine = Resolve-Path (Join-Path $PSScriptRoot '..\..')

Push-Location $racine
npm install --no-audit --no-fund
# L'application importe @win/shared, qui doit etre compile avant d'etre lisible.
npm run build --workspace @win/shared
Pop-Location

Push-Location $PSScriptRoot
npm install --no-audit --no-fund
Bien "Dependances pretes"

# --- 3. eas-cli -----------------------------------------------------------
Etape 3 "Verification de l'outil de compilation Expo"

$easPresent = $null -ne (Get-Command eas -ErrorAction SilentlyContinue)
if (-not $easPresent) {
    Souci "eas-cli absent, installation en cours..."
    npm install -g eas-cli
}
Bien "eas-cli $(eas --version)"

# --- 4. Compte Expo -------------------------------------------------------
Etape 4 "Compte Expo"

$connecte = $true
try { $qui = eas whoami 2>$null } catch { $connecte = $false }
if (-not $connecte -or [string]::IsNullOrWhiteSpace($qui)) {
    Souci "Vous n'etes pas connecte. Creez un compte gratuit sur https://expo.dev si besoin."
    eas login
    $qui = eas whoami
}
Bien "Connecte en tant que $qui"

# --- 5. Identifiant de projet --------------------------------------------
Etape 5 "Identifiant de projet"

$config = Get-Content (Join-Path $PSScriptRoot 'app.json') -Raw | ConvertFrom-Json
$projet = $config.expo.extra.eas.projectId

if ([string]::IsNullOrWhiteSpace($projet) -or $projet -like 'a-renseigner*') {
    Souci "Premier lancement : creation du projet chez Expo."
    eas init
} else {
    Bien "Projet deja enregistre ($projet)"
}

# --- 6. Compilation -------------------------------------------------------
Etape 6 "Compilation de l'APK chez Expo"

Write-Host "      Comptez 20 a 45 minutes. Vous pouvez fermer cette fenetre :" -ForegroundColor DarkGray
Write-Host "      la compilation continue, et le lien reste disponible sur" -ForegroundColor DarkGray
Write-Host "      https://expo.dev dans la section Builds." -ForegroundColor DarkGray
Write-Host ""

eas build --platform android --profile preview

Pop-Location

Write-Host ""
Write-Host "  Termine." -ForegroundColor Green
Write-Host "  Ouvrez le lien affiche ci-dessus sur votre telephone, telechargez" -ForegroundColor White
Write-Host "  le fichier .apk et autorisez l'installation depuis cette source." -ForegroundColor White
Write-Host ""
