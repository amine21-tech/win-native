import {
  Camera,
  GeoJSONSource,
  Layer,
  Map,
  UserLocation,
  type CameraRef,
} from '@maplibre/maplibre-react-native';
import { useQuery } from '@tanstack/react-query';
import * as Location from 'expo-location';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { NEARBY_RADIUS_M, type Report } from '@win/shared';
import { api } from '../src/api/client';
import { useRealtime } from '../src/hooks/useRealtime';
import { INITIAL_VIEW_STATE, MAP_STYLES, REPORT_COLORS } from '../src/map/style';
import { HIT_SIZE, palette, radius, spacing, typography } from '../src/theme';

type Position = { lat: number; lon: number };

export default function MapScreen() {
  const { t } = useTranslation();
  const scheme = useColorScheme() ?? 'light';
  const colors = palette[scheme === 'dark' ? 'dark' : 'light'];
  const insets = useSafeAreaInsets();
  const cameraRef = useRef<CameraRef>(null);

  const [position, setPosition] = useState<Position | null>(null);
  const [permissionDenied, setPermissionDenied] = useState(false);
  const [liveReports, setLiveReports] = useState<Report[]>([]);

  /* ------------------------------------------------------------------ */
  /* Position                                                            */
  /* ------------------------------------------------------------------ */

  useEffect(() => {
    let subscription: Location.LocationSubscription | null = null;

    void (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setPermissionDenied(true);
        return;
      }
      subscription = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.BestForNavigation,
          distanceInterval: 15,
          timeInterval: 3000,
        },
        (location) => {
          setPosition({ lat: location.coords.latitude, lon: location.coords.longitude });
        },
      );
    })();

    return () => subscription?.remove();
  }, []);

  /* ------------------------------------------------------------------ */
  /* Signalements : chargement initial puis mises a jour temps reel      */
  /* ------------------------------------------------------------------ */

  const { data, isLoading } = useQuery({
    // La cle est arrondie a deux decimales, soit environ un kilometre :
    // sans cela, chaque rafraichissement GPS relancerait une requete.
    queryKey: ['reports', position?.lat.toFixed(2), position?.lon.toFixed(2)],
    enabled: position !== null,
    queryFn: () =>
      api<{ items: Report[] }>('/reports/nearby', {
        query: { lat: position!.lat, lon: position!.lon, radius: NEARBY_RADIUS_M },
      }),
  });

  useEffect(() => {
    if (data?.items) setLiveReports(data.items);
  }, [data]);

  useRealtime(position, {
    onNew: (report) => setLiveReports((current) => [report, ...current]),
    onUpdated: (report) =>
      setLiveReports((current) => current.map((r) => (r.id === report.id ? report : r))),
    onRemoved: (reportId) => setLiveReports((current) => current.filter((r) => r.id !== reportId)),
  });

  /** Les signalements passent a la carte sous forme de GeoJSON. */
  const reportsGeoJson = useMemo<GeoJSON.FeatureCollection>(
    () => ({
      type: 'FeatureCollection',
      features: liveReports.map((report) => ({
        type: 'Feature',
        id: report.id,
        properties: { kind: report.kind, color: REPORT_COLORS[report.kind] ?? '#D64545' },
        geometry: { type: 'Point', coordinates: [report.lon, report.lat] },
      })),
    }),
    [liveReports],
  );

  const recenter = useCallback(() => {
    if (!position) return;
    cameraRef.current?.easeTo({
      center: [position.lon, position.lat],
      zoom: 15,
      duration: 700,
    });
  }, [position]);

  /* ------------------------------------------------------------------ */

  return (
    <View style={styles.root}>
      <Map
        style={StyleSheet.absoluteFill}
        mapStyle={scheme === 'dark' ? MAP_STYLES.night : MAP_STYLES.day}
        logo={false}
        attribution
        attributionPosition={{ bottom: 8, right: 8 }}
        touchRotate
        touchPitch
      >
        <Camera ref={cameraRef} initialViewState={INITIAL_VIEW_STATE} />
        <UserLocation animated heading minDisplacement={5} />

        <GeoJSONSource id="reports" data={reportsGeoJson}>
          {/* Halo large : visible du coin de l'oeil, sans masquer la route. */}
          <Layer
            id="reports-halo"
            type="circle"
            source="reports"
            paint={{
              'circle-radius': 16,
              'circle-color': ['get', 'color'],
              'circle-opacity': 0.18,
            }}
          />
          <Layer
            id="reports-dot"
            type="circle"
            source="reports"
            paint={{
              'circle-radius': 7,
              'circle-color': ['get', 'color'],
              'circle-stroke-width': 2,
              'circle-stroke-color': colors.surface,
            }}
          />
        </GeoJSONSource>
      </Map>

      {/* Bandeau d'information, en haut */}
      <View style={[styles.top, { top: insets.top + spacing.md }]} pointerEvents="none">
        {permissionDenied ? (
          <View style={[styles.pill, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.pillText, { color: colors.text }]}>{t('map.locationDenied')}</Text>
          </View>
        ) : liveReports.length > 0 ? (
          <View style={[styles.pill, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.pillText, { color: colors.text }]}>
              {t('map.reportsNearby', { count: liveReports.length })}
            </Text>
          </View>
        ) : null}
      </View>

      {/* Colonne de boutons, en bas a droite */}
      <View style={[styles.column, { bottom: insets.bottom + spacing.xl }]}>
        {isLoading ? <ActivityIndicator color={colors.accent} /> : null}

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t('map.locateMe')}
          onPress={recenter}
          style={({ pressed }) => [
            styles.fab,
            {
              backgroundColor: colors.surface,
              borderColor: colors.border,
              opacity: pressed ? 0.7 : 1,
            },
          ]}
        >
          <Text style={[styles.fabGlyph, { color: colors.accent }]}>◎</Text>
        </Pressable>

        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t('report.add')}
          style={({ pressed }) => [
            styles.fab,
            styles.fabPrimary,
            { backgroundColor: colors.accent, opacity: pressed ? 0.8 : 1 },
          ]}
        >
          <Text style={[styles.fabGlyph, { color: colors.accentText }]}>△</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  top: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    alignItems: 'center',
    gap: spacing.sm,
  },
  pill: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    maxWidth: '100%',
  },
  pillText: { ...typography.caption, textAlign: 'center' },
  column: {
    position: 'absolute',
    right: spacing.lg,
    gap: spacing.md,
    alignItems: 'center',
  },
  fab: {
    width: HIT_SIZE,
    height: HIT_SIZE,
    borderRadius: radius.pill,
    borderWidth: StyleSheet.hairlineWidth,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  fabPrimary: { width: 64, height: 64, borderWidth: 0 },
  fabGlyph: { fontSize: 24, lineHeight: 28 },
});
