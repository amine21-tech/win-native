/**
 * Fonds de carte.
 *
 * OpenFreeMap est deja la source de la version web : garder le meme fournisseur
 * evite une rupture visuelle entre l'application et le site pendant les mois ou
 * les deux coexisteront.
 */
export const MAP_STYLES = {
  day: 'https://tiles.openfreemap.org/styles/liberty',
  night: 'https://tiles.openfreemap.org/styles/dark',
} as const;

/** Vue d'ouverture : l'Algerie entiere, centree sur les hauts plateaux. */
export const INITIAL_VIEW_STATE = {
  center: [2.6, 34.5] as [number, number],
  zoom: 4.6,
};

/** Reglages de camera quand le guidage est actif. */
export const NAVIGATION_CAMERA = {
  zoom: 17,
  pitch: 55,
};

/**
 * Couleur d'un signalement sur la carte. Les trois types permanents partagent
 * l'ambre ; les evenements ponctuels prennent le rouge.
 */
export const REPORT_COLORS: Record<string, string> = {
  radar: '#EFB63F',
  bump: '#EFB63F',
  pothole: '#EFB63F',
  police: '#4A7DD4',
  crash: '#D64545',
  jam: '#D6822C',
  object: '#D64545',
  fire: '#D64545',
  flood: '#4A7DD4',
  block: '#D64545',
};
