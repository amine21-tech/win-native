import Constants from 'expo-constants';
import { storage } from '../store/storage';

const BASE_URL =
  (Constants.expoConfig?.extra as { apiBaseUrl?: string } | undefined)?.apiBaseUrl ??
  'http://10.0.2.2:3001';

export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
    readonly details?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

type Options = {
  method?: 'GET' | 'POST' | 'PATCH' | 'DELETE';
  body?: unknown;
  query?: Record<string, string | number | undefined>;
  /** Jeton administrateur, quand la route l'exige. */
  adminToken?: string;
  signal?: AbortSignal;
};

/**
 * Appel API.
 *
 * Le jeton appareil est ajoute automatiquement : aucun ecran n'a besoin de
 * savoir qu'il existe. Les messages d'erreur du serveur sont deja rediges en
 * francais et peuvent etre affiches tels quels.
 */
export async function api<T>(path: string, options: Options = {}): Promise<T> {
  const url = new URL(BASE_URL.replace(/\/$/, '') + path);
  for (const [key, value] of Object.entries(options.query ?? {})) {
    if (value !== undefined) url.searchParams.set(key, String(value));
  }

  const token = options.adminToken ?? storage.getString('deviceToken');
  const headers: Record<string, string> = { accept: 'application/json' };
  if (token) headers.authorization = `Bearer ${token}`;
  if (options.body !== undefined) headers['content-type'] = 'application/json';

  const response = await fetch(url.toString(), {
    method: options.method ?? 'GET',
    headers,
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
    signal: options.signal,
  });

  const text = await response.text();
  const payload: unknown = text ? JSON.parse(text) : null;

  if (!response.ok) {
    const error = payload as { error?: string; message?: string; details?: unknown } | null;
    throw new ApiError(
      response.status,
      error?.error ?? 'erreur_reseau',
      error?.message ?? "Le serveur n'a pas repondu correctement.",
      error?.details,
    );
  }

  return payload as T;
}

/** Envoi d'une photo en multipart. */
export async function uploadPhoto(uri: string): Promise<{ id: string; url: string }> {
  const form = new FormData();
  form.append('file', {
    uri,
    name: 'photo.jpg',
    type: 'image/jpeg',
  } as unknown as Blob);

  const token = storage.getString('deviceToken');
  const response = await fetch(`${BASE_URL.replace(/\/$/, '')}/photos`, {
    method: 'POST',
    headers: token ? { authorization: `Bearer ${token}` } : undefined,
    body: form,
  });

  if (!response.ok) {
    throw new ApiError(response.status, 'photo_refusee', "La photo n'a pas pu etre envoyee.");
  }
  return (await response.json()) as { id: string; url: string };
}

export { BASE_URL };
