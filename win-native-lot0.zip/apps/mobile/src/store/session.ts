import { create } from 'zustand';
import type { Language } from '@win/shared';
import { api } from '../api/client';
import { readJson, storage, StorageKeys, writeJson } from './storage';

type Session = {
  deviceId: string | null;
  language: Language;
  consentAccepted: boolean;
  favorites: string[];
  ready: boolean;

  /** Inscrit l'appareil au premier lancement, puis reutilise le jeton garde. */
  bootstrap: () => Promise<void>;
  setLanguage: (language: Language) => void;
  acceptConsent: () => void;
  toggleFavorite: (placeId: string) => void;
};

export const useSession = create<Session>((set, get) => ({
  deviceId: storage.getString(StorageKeys.deviceId) ?? null,
  language: (storage.getString(StorageKeys.language) as Language | undefined) ?? 'fr',
  consentAccepted: storage.getString(StorageKeys.consentAcceptedAt) !== undefined,
  favorites: readJson<string[]>(StorageKeys.favorites, []),
  ready: false,

  bootstrap: async () => {
    const existing = storage.getString(StorageKeys.deviceToken);
    if (existing) {
      set({ ready: true });
      void api('/devices/heartbeat', { method: 'POST' }).catch(() => {
        /* hors ligne : sans consequence */
      });
      return;
    }

    try {
      const session = await api<{ deviceId: string; token: string }>('/devices/register', {
        method: 'POST',
        body: { platform: 'android', language: get().language },
      });
      storage.set(StorageKeys.deviceId, session.deviceId);
      storage.set(StorageKeys.deviceToken, session.token);
      set({ deviceId: session.deviceId, ready: true });
    } catch {
      // Premiere ouverture sans reseau : la carte reste utilisable, on
      // reessaiera au prochain lancement.
      set({ ready: true });
    }
  },

  setLanguage: (language) => {
    storage.set(StorageKeys.language, language);
    set({ language });
  },

  acceptConsent: () => {
    storage.set(StorageKeys.consentAcceptedAt, new Date().toISOString());
    set({ consentAccepted: true });
  },

  toggleFavorite: (placeId) => {
    const current = get().favorites;
    const next = current.includes(placeId)
      ? current.filter((id) => id !== placeId)
      : [placeId, ...current];
    writeJson(StorageKeys.favorites, next);
    set({ favorites: next });
  },
}));
