/**
 * Palette de l'application.
 *
 * Le vert profond reprend la signaletique routiere algerienne ; l'ambre sert
 * exclusivement aux alertes, pour qu'un conducteur qui apercoit la couleur du
 * coin de l'oeil sache deja de quoi il s'agit sans lire.
 */
export const palette = {
  light: {
    background: '#F2F4F3',
    surface: '#FFFFFF',
    surfaceAlt: '#E8ECEA',
    text: '#10161A',
    textMuted: '#5D6B69',
    border: '#D3DAD8',
    accent: '#006B45',
    accentText: '#FFFFFF',
    alert: '#B4690E',
    danger: '#9B2C2C',
  },
  dark: {
    background: '#0D1214',
    surface: '#151D1F',
    surfaceAlt: '#1D2729',
    text: '#E4EBE8',
    textMuted: '#8B9A96',
    border: '#26332F',
    accent: '#46C58C',
    accentText: '#06231A',
    alert: '#EFB63F',
    danger: '#E88B8B',
  },
} as const;

export type Palette = (typeof palette)['light'];

export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 } as const;

export const radius = { sm: 6, md: 10, lg: 16, pill: 999 } as const;

/**
 * Taille minimale des zones tactiles. En navigation, l'utilisateur vise mal :
 * on ne descend jamais sous 52 points, au-dessus des 44 recommandes.
 */
export const HIT_SIZE = 52;

export const typography = {
  title: { fontSize: 22, fontWeight: '700' },
  heading: { fontSize: 17, fontWeight: '600' },
  body: { fontSize: 15, fontWeight: '400' },
  caption: { fontSize: 13, fontWeight: '400' },
  /** Consigne de navigation : lisible d'un coup d'oeil, au volant. */
  instruction: { fontSize: 26, fontWeight: '700' },
} as const;
